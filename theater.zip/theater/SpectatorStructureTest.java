package theater;

public class SpectatorStructureTest {
    
}
