package theater.seating;

public enum SeatType {
    OT, MT, IT;
}
